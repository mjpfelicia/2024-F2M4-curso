# Instructions  
Olá!

Nessa atividade você vai colocar em prática o conteúdo abordado na Semana 3. 

ESSA ATIVIDADE  SERÁ DESENVOLVIDA NO REPL.IT E DEVERÁ SER POSTADA NESTA TAREFA EM ARQUIVO ZIP, CONFORME ORIENTAÇÕES ABAIXO:

Orientações:

_ Assista aos vídeos das aulas desta semana.
_ Leia em paralelo os materiais das aulas desta semana.
_ Acesse o Replit.
_ Você vai utilizar a aplicação desenvolvida durante a semana.
_ Utilizando o ORM Sequelize, crie um model chamado fornecedor.js dentro da pasta models.
_ Crie o model fornecedor com os seguintes campos:
    _ id tipo int restrição primary key;
    _ nome tipo string;
    _ telefone tipo string;
    _ email tipo string;
    
_ Crie o formulário para inserção dos campos do fornecedor chamado formFornecedor.html dentro da pasta views com os campos para inserção dos dados do fornecedor. O action do formulário deve ser /addfornecedor e method="post"
_ No arquivo index.js, crie a rota POST para a operação create (criar) registros na tabela fornecedor.
_ Insire 3 registros na tabela fornecedores.

Se a atividade não estiver sendo mostrada para você, entre em contato com o monitor ou professor mediador o quanto antes.

Bons estudos e boa atividade!

Valor: 10 pontos.