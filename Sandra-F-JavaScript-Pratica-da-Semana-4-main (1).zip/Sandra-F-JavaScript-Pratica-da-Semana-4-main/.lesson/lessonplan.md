# Rubrica de correção
  ![Grade](assets/F1-M3-Sem04-Praticas-Grade.png)
