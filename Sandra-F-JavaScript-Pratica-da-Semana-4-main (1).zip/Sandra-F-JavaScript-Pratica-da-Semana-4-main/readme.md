## Instituto Federal do Espírito Santo

# Sandra-F-JavaScript-Pratica-da-Semana-4
# https://github.com/mjpfelicia

                 Welcome! 👋
                 
<img src="./img/javsript4.png" alt="Site em Telas" />
## Índice

- Desafio
- Links
- Tecnologias usadas
- O que eu aprendi
- Recursos úteis
- Desafio


## Links usados:

- https://youtu.be/sd61AB8qaHY?si=CPbESyM5Q9GPFjmI
- https://youtu.be/sd61AB8qaHY?si=CPbESyM5Q9GPFjmI




## Tecnologias usadas:
- Javascript


## O que eu aprendi

- Implementar comando de repetição (for)
- Implementar os comandos de decisão para verificar números quadrados pares ou ímpares
- Praticando para melhorar o javascript- -

## Autor
- @mjpfelicia