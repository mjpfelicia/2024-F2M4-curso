const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const path = require("path");
const nodemailer = require("nodemailer");

const app = express();
const port = 443;

app.use(session({ secret: "1234567890" }));
app.use(bodyParser.urlencoded({ extended: true }));

var login = "admin";
var senha = "1234";

app.engine("html", require("ejs").renderFile);
app.set("view engine", "html");
app.set("views", path.join(__dirname, "./"));

app.get("/", (req, res) => {
  if (req.session.login) {
    res.render("logado");
    console.log("Usuário logado: " + req.session.login);
  } else {
    res.render("home");
  }
});

app.post("/", (req, res) => {
  if (req.body.password == senha && req.body.login == login) {
    req.session.login = login;
    res.render("logado");
  } else {
    console.log("qualquer");
    res.render("home");
  }
});


app.post("/sendemail", async (req, res) => {

  console.log({ body: req.body });

  var transport = nodemailer.createTransport({
    host: "sandbox.smtp.mailtrap.io",
    port: 2525,
    auth: {
      user: "7bb748fbe27aad",
      pass: "879d3277ac8666"
    }
  });

  var message = {
    from: "sender@server.com",
    to: req.body.email,
    subject: "Prática da 4ª semana",
    text: "Enviando e-mail com o Nodemailer",
    html: "<p>Autenticando usuários no Node.js</p>",
  };

  console.info({ message })

  transport.sendMail(message, function (err, info) {

    if (err) {
      console.error({ err })
      return res.status(400).json({
        erro: true,
        mensagem: "Erro: E-mail não enviado!",
        message: err.message,
      });
    }


    return res.json({
    
      mensagem: "E-mail enviado com sucesso!",
    });
  });
});



app.listen(port, () => {
  console.log(`Servidor rodando ${port}`);
});

