# Rubrica de correção
  ![Grade](assets/F1-M3-Sem02-Praticas-Grade.png)