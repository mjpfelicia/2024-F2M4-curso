## Instituto Federal do Espírito Santo

# Sandra-F-JavaScript-Pratica-da-Semana-2 
# https://github.com/mjpfelicia

<img src="img/1validacao.png" alt="Site em Telas" />
<img src="img/2validacao.png" alt="Site em Telas" />
<img src="img/3validacao.png" alt="Site em Telas" />
<img src="img/4validacao.png" alt="Site em Telas" />



                 Welcome! 👋

## Índice

- Desafio
- Links
- Tecnologias usadas
- O que eu aprendi
- Recursos úteis
- javascript


## Links usados:

- https://developer.mozilla.org/en-US/docs/Web/JavaScript
- https://youtu.be/1bFpiRU7q2g?si=AAGKqC9JsVkAf-oY