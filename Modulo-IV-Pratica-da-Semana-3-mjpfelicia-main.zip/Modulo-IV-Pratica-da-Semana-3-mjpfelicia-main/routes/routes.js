const express = require("express");
const Services = require("../services/services");
const router = express.Router();

// rota orincipal
router.get("/", (req, res) => {
  res.render("usuario/cadastrar");
});

// rota para o serviso de create
router.post("/usuario/create", Services.usuarioCreate);


// rota para o serviso de create
router.get("/usuario/listar", Services.usuarioListar);


router.get("/usuario/Atualizar/:id/:nome/:email/:senha?", (req, res) => {

  const usuario = {
    id_usuario: req.params.id,
    nome: req.params.nome,
    email: req.params.email,
    senha: req.params.senha,
  };

  res.render("usuario/update", { usuario })
})

router.post("/usuario/update", Services.usuarioAtualizar)

router.post("/usuario/Delete", Services.usuarioDelete)
        
        


module.exports = router;