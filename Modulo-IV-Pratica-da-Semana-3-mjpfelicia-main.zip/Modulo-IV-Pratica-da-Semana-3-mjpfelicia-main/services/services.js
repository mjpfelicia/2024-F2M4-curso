
const axios = require("axios");

const URL_API_USUARIOS =
  "https://ca5d8a10-b616-40cd-9bc9-1c0418949774-00-2qtvgb0o9acc9.janeway.replit.dev/usuarios";


module.exports = class Services {
  // Função para criar uma usuario
  static async usuarioCreate(req, res) {
    let valores = req.body;
    const options = {
      url: URL_API_USUARIOS + "/Cadastrar",
      method: "POST",
      data: valores,
    };
    await axios(options).then(response => {
      const mensagem = "Cadastro realizado com sucesso!";
      res.render("mensagem", { mensagem });
    }).catch((error) => {
      console.log({ error: error.message })
    });
  }

  //LISTAR
  static async usuarioListar(req, res) {

    console.log('Services usuarioListar ');

    const options = {
      url: URL_API_USUARIOS,
      method: "GET",
    };

    await axios(options)
      .then((response) => {

        const usuarios = response.data;

        res.render("usuario/listar", { usuarios });
      })
      .catch((error) => {
        console.log("ERROR: ", error.message);
      });
  }

  static async usuarioAtualizar(req, res) {
    console.log('Services usuarioAtualizar ');

    const { nome, email, senha, id_usuario} = req.body;
    // const id_usuario = req.params.id;

    const usuario = {
      nome, email, senha
    };

    console.log({ id_usuario, usuario });

    const options = {
      url: URL_API_USUARIOS + `/${id_usuario}`,
      method: "PUT",
      data: usuario
    };

    await axios(options)
      .then(response => {
        res.redirect("/usuario/listar");
      }).catch(error => {
        console.error("[ERROR] usuarioAtualizar: ", { error });
      })

  }

  static async usuarioDelete(req, res) {
    console.log("usuarioDelete")
    const id_usuario = req.body.id_usuario;
    
    const options = {
      url: URL_API_USUARIOS + "/" + id_usuario,
              method: "DELETE",
      data: {},
    };
    await axios(options)
      .then((response) => {
        console.log("deletado", response.data);
        const mensagem = "Registro deletado com sucesso";
        res.render("mensagem", { mensagem });
      })
      .catch((error) => {
        console.log("erro", error);
      });
  }

};
