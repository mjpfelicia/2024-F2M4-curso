# Instructions  
Olá!

Nessa atividade você vai colocar em prática o conteúdo abordado na Semana 2. 

ESSA ATIVIDADE  SERÁ DESENVOLVIDA NO REPL.IT E DEVERÁ SER POSTADA NESTA TAREFA EM ARQUIVO ZIP E NO REPL. IT CONFORME ORIENTAÇÕES ABAIXO:

Orientações:

_ Assista ao vídeo das aulas da semana.
_ Leia em paralelo o material das aulas.
_ Acesse o Replit.
_ Você vai utilizar o banco de dados desenvolvido na semana.
_ Utilizando o ORM Sequelize, insira 3 novos setores (Contabilidade, Diretoria e Recursos humanos na tabela setor do banco de dados criado com todas as informações referentes a tabela setor.
_ Exclua o setor Contabilidade do banco de dados.
_ Altere o nome do setor Recursos Humanos para Departamento Pessoal.
_ Liste todos os setores da tabela na tela.
_ Salve o código no seu computador.
_ Compacte o arquivo.
_ Envie o arquivo aqui.
_ Poste sua atividade no Repl. it.

Se a atividade não estiver sendo mostrada para você, entre em contato com o monitor ou professor mediador o quanto antes.

Bons estudos e boa atividade!

Valor: 8 pontos.