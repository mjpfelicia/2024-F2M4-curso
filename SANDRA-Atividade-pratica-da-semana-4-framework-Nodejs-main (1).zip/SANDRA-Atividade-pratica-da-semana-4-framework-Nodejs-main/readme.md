# Instituto Federal do Espírito Santo
# 2024-F2M1: Introdução ao framework Node.js e notação Javascript.
# https://github.com/mjpfelicia/SANDRA-Atividade-pratica-da-semana-4-framework-Nodejs

![Exemplo](/.lesson/assets/img/Pratica4.gif)

                 Welcome! 👋

## Índice

- Desafio
- Links
- Tecnologias usadas
- O que eu aprendi
- Recursos úteis



## Links usados:

- https://youtu.be/xI1VrTH0u9s?si=UMM0J4eGYqfNeYSI
- https://youtu.be/38G-uPi8rRI?si=dMTKgEkcrNQoA9yB
- https://developer.mozilla.org/pt-BR/docs/Web/HTTP/Methods




## Tecnologias usadas:
- javascript

## O que eu aprendi

- Melhorando as habilidades
- Marcadores semânticos importantes - javascript 
- Praticando para melhorar o javascript

## Autor
- @mjpfelicia
