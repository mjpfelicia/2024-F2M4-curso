const prompt = require("prompt-sync")();

// Leia os três números

// Calcule a soma e a média

// Mostre na tela o valor da soma e média




const n1 = parseInt(prompt('Informe o primeiro número:'));
const n2 = parseInt(prompt('Informe o segundo número:'));
const n3 = parseInt(prompt('Informa o terceiro número:'));
const soma = (n1 + n2 + n3);

const media = (n1 + n2 + n3) / 3;

console.log("o primeiro número", n1)
console.log("o segundo número", n2)
console.log("o terceiro número", n3)
console.log("A soma e", soma)
console.log("A media ficou em:", media)



