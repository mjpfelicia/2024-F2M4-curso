## Instituto Federal do Espírito Santo
 ## 2024-F2M2: Criação de páginas customizadas com Node.js
<img src="/arquivos/fotos/feliciabolsas.png" alt="Site em Telas" />



                 Welcome! 👋

## Índice

- Desafio
- Links
- Tecnologias usadas
- O que eu aprendi
- Recursos úteis
- Desafio
- layout ideal para a seção, dependendo do tamanho da tela


## Links usados:

- https://youtu.be/sXP08RElyWE?si=dNsyXBVtvO5aBW8D
- https://youtu.be/64KEwiEcX8c?si=kFN6_qjyWX_31-gY
- https://youtu.be/QhXt2WOShJk?si=279tbXcj0SJZ443-
- https://youtu.be/Zca6YqR8In0?si=lL7qFntIkyttdX--




## Tecnologias usadas:
- Marcação HTML5 semântica
- CSS
- node express
- Introdução ao Framework Express Página
- Servidor Web com ExpressPágina
- Carregando arquivo HTML utilizando ExpressPágina
- Criando rotas no Servidor WebPágina


## O que eu aprendi

- Melhorando as habilidades no CSS
- Marcadores semânticos importantes -Express
- Praticando para melhorar o -  node

## Autor
- @mjpfelicia
