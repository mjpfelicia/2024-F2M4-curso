const express = require("express");
const Services = require("../services/services");
const router = express.Router();



router.post("/login", Services.FuncionarioLogin);
router.get("/", (req, res) => {
  res.render("funcionarios/login");
});

router.get("/funcionario/Cadastrar", (req, res) => {
  res.render("funcionarios/Cadastrar");
});
router.post("/funcionario/Cadastrar", Services.FuncionarioCreate);

// create produto
router.get("/livros/Cadastrar", (req, res) => {
  res.render("livros/Cadastrar");
});
router.post("/livros/Cadastrar", Services.LivrosCreate);

router.get("/livros/listar", Services.LivrosListar);

//rotas para os cookies
router.get("/carrinho/Adicionar/:id/:nome", Services.CarrinhoAdicionar);
router.get("/carrinho/listar", Services.CarrinhoListar);
router.get("/carrinho/remover/:item", Services.CarrinhoRemoverItem);

module.exports = router;
