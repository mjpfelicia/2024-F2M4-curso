Olá!

Nessa atividade você vai colocar em prática o conteúdo abordado no módulo 4.

ESSA ATIVIDADE  SERÁ DESENVOLVIDA NO REPL.IT E DEVERÁ SER POSTADA SOMENTE OS ARQUIVOS NESTA TAREFA EM ARQUIVO ZIP, CONFORME ORIENTAÇÕES ABAIXO:

Orientações:

_Assista aos vídeos das aulas da semana.
_Leia em paralelo os materiais das aulas.
_Acesse o Replit.
_Crie uma API chamada API_LIVRARIA com os models:
    _Funcionario(
      id_funcionario integer,chave primária,
      nome string,
      email string,
      senha string.
    _livros(
      id_livro integer, chave primária,
      Titulo string,
      autor string,
      preco string.
      link imagem(utilize o link da imagem na web para cadastro, conforme nossa atividade da semana 4.
_Crie uma aplicação que consuma sua API e faça login no sistema e realize cadastro de livros.
_Não será necessário colocar as opções de update e deletar para o funcionário e livros.
_Salve o código no seu computador.
_Compacte o arquivo.
_Envie o link do repl.it e o arquivo aqui.

Pessoal a atividade é semelhante ao que fizemos durante as aulas da semana, basta realizar as alterações incluindo as rotas e as views na aplicação, lembre-se de olhar o caminho da sua API e as rotas que irá utilizar.

Se a atividade não estiver sendo mostrada para você, entre em contato com o monitor ou professor mediador o quanto antes.

Bons estudos e boa atividade!

Valor: 20 pontos.