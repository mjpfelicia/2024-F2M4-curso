const axios = require("axios");
const { error } = require("console");
const URL_API_LIVRARIA = "https://fb5408ad-2c2c-4896-b54c-d60e4b8863ad-00-1fprs848np69p.worf.replit.dev"

module.exports = class Services {
  static async FuncionarioLogin(req, res) {
    let valores = req.body;
    console.groupCollapsed(valores)
    const options = {
      url: URL_API_LIVRARIA + "/login",
      method: "POST",
      data: valores,
    };
    return axios(options).then((sucesso) => {
      const mensagem = "Login realizado com sucesso!";
      res.render("logado");
    }).catch((error) => {
      console.error(error.message);
      throw error;
    });
  }

  static async FuncionarioCreate(req, res) {
    let valores = req.body;
    const options = {
      url: URL_API_LIVRARIA + "/add_funcionario",
      method: "POST",
      data: valores,
    };
    axios(options).then(response => {
      const mensagem = "Cadastro realizado com sucesso!";
      res.render("mensagem", { mensagem });
    }).catch(error => {
      console.error(error)
    });
  }

  // create livros
  static async LivrosCreate(req, res) {
    let livros = req.body;
    console.log("livros", livros)
    const options = {
      url: URL_API_LIVRARIA + "/add_livro",
      method: "POST",
      data: livros,
    };
    axios(options).then((response) => {
      const mensagem = "Livros cadastrado com sucesso!";
      res.render("mensagem", { mensagem });

    }).catch((error) => {
      console.error(error.message)
    })
  }

  // listar livros
  static async LivrosListar(req, res) {
    const options = {
      url: URL_API_LIVRARIA + "/livros",
      method: "GET",
      data: {},
    };
    axios(options).then((response) => {

      const livros = response.data;
      console.log(livros);
      const mensagem = "Lista de livros!";
      res.render("livros/listar", { livros, mensagem });
    }).catch((error) => {
      console.error(error.message)
    })
  }

  // cookies
  static async CarrinhoAdicionar(req, res) {
    const item = {
      id: req.params.id,
      nome: req.params.nome,
    };
    // Verificando se já existe um cookie para o carrinho
    if (req.cookies.carrinho) {
      // Se já existe, adiciona o novo item
      const carrinho = JSON.parse(req.cookies.carrinho);
      carrinho.push(item);
      res.cookie("carrinho", JSON.stringify(carrinho), {
        maxAge: 900000,
        httpOnly: true,
      });
    } else {
      // Se não existe, cria um novo carrinho com o item
      const carrinho = [item];
      res.cookie("carrinho", JSON.stringify(carrinho), {
        maxAge: 900000,
        httpOnly: true,
      });
    }
    res.send("item adicionado ao carrinho");
  }

  // Rota para remover um itedo carrinho
  static async CarrinhoRemoverItem(req, res) {
    const itemDeletar = req.params.item;
    if (req.cookies.carrinho) {
      const carrinho = JSON.parse(req.cookies.carrinho);

      const novoCarrinho = carrinho.filter((item) => item.id !== itemDeletar);
      res.cookie("carrinho", JSON.stringify(novoCarrinho), {
        maxAge: 900000,
        httpOnly: true,
      });
      res.send("Itemremovido do carrinho");
    } else {
      res.send("Carrinho vazio");
    }
  }

  //listar carrinho
  static async CarrinhoListar(req, res) {
    // Rota para exibir o carrinho
    if (req.cookies.carrinho) {
      const carrinho = JSON.parse(req.cookies.carrinho);
      res.render("carrinhos/Listar", { carrinho });
    } else {
      res.send("Carrinho vazio");
    }
  }












}
